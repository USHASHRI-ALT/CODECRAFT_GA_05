# CODECRAFT Task 5 – Neural Style Transfer

**Author**: Usha

## Description
This project applies Neural Style Transfer using TensorFlow Hub. It combines the content of a panda image with the artistic style of a painting to generate a unique image.

## Files Included
- content.jpg.jpeg – Your panda image
- style.jpg.jpg – The style painting
- stylized_panda.jpg – Output image
- neural_style_transfer.py – Main script
- requirements.txt – List of dependencies

## Instructions
1. Ensure you have TensorFlow and the listed libraries installed.
2. Run `neural_style_transfer.py` to generate your result.
